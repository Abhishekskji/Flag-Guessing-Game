import React, { useState } from 'react';

const flags = [
  { country: 'France', url: '/assets/flags/france.png' },
  { country: 'Germany', url: '/assets/flags/germany.png' },
  { country: 'Italy', url: '/assets/flags/italy.png' },
  // Add more flags here
];

function FlagComponent() {
  const [currentFlag, setCurrentFlag] = useState(flags[0]);

  const nextFlag = () => {
    const randomIndex = Math.floor(Math.random() * flags.length);
    setCurrentFlag(flags[randomIndex]);
  };

  return (
    <div>
      <img src={currentFlag.url} alt={currentFlag.country} />
      <button onClick={nextFlag}>Next Flag</button>
    </div>
  );
}

export default FlagComponent;