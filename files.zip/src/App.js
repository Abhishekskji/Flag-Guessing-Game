import React from 'react';
import FlagComponent from './components/FlagComponent';

function App() {
  return (
    <div className="App">
      <h1>Flag Guessing Game</h1>
      <FlagComponent />
    </div>
  );
}

export default App;