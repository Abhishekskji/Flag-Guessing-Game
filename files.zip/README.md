# Flag Guessing Game

A simple flag guessing game built with React.

## How to Run

1. Clone the repository
2. Install dependencies: `npm install`
3. Start the development server: `npm start`

## How to Play

Click the "Next Flag" button to display a random flag. Try to guess the country the flag belongs to!